const TOKEN = "BtC_92fA7xP14_QmZ87Lw3vS4nHk";
const API_BASE = ""; // same origin

const tempEl = document.getElementById("temperature");
const relaySetEl = document.getElementById("relaySet");
const relayEspEl = document.getElementById("relayESP");
const browserTimeEl = document.getElementById("browserTime");
const espTimeEl = document.getElementById("espTime");
const lastUpdateEl = document.getElementById("lastUpdate");
const modeLabel = document.getElementById("modeLabel");

const onBtn = document.getElementById("onBtn");
const offBtn = document.getElementById("offBtn");
const manualBtn = document.getElementById("manualBtn");
const autoBtn = document.getElementById("autoBtn");
const minInput = document.getElementById("minTempInput");
const maxInput = document.getElementById("maxTempInput");
const saveRangeBtn = document.getElementById("saveRangeBtn");

function formatTime(ts) {
  if (!ts) return "--";
  const n = Number(ts);
  if (Number.isNaN(n)) return "--";
  return new Date(n).toLocaleString("ro-RO");
}

async function updateData() {
  try {
    const res = await fetch(`${API_BASE}/api/temp?token=${TOKEN}`);
    const data = await res.json();

    const temp = parseFloat(data.temp ?? "0");
    tempEl.textContent = `${temp.toFixed(1)} °C`;

    modeLabel.textContent = (data.mode ?? "manual").toUpperCase();

    relaySetEl.textContent = (data.relaySet ?? "off").toUpperCase();
    relaySetEl.style.color = data.relaySet === "on" ? "#4caf50" : "#f44336";

    relayEspEl.textContent = (data.relayESP ?? "off").toUpperCase();
    relayEspEl.style.color = data.relayESP === "on" ? "#4caf50" : "#f44336";

    browserTimeEl.textContent = formatTime(data.lastBrowserUpdate);
    espTimeEl.textContent = formatTime(data.lastEspUpdate);
    lastUpdateEl.textContent = "Ultima actualizare ESP: " + formatTime(data.lastEspUpdate);

    if (data.minTemp) minInput.value = data.minTemp;
    if (data.maxTemp) maxInput.value = data.maxTemp;
  } catch (e) {
    console.error(e);
    lastUpdateEl.textContent = "Eroare la citire date";
  }
}

async function setRelay(state) {
  await fetch(`${API_BASE}/api/relay?token=${TOKEN}&state=${state}`);
  updateData();
}

async function setMode(value) {
  await fetch(`${API_BASE}/api/mode?token=${TOKEN}&value=${value}`);
  updateData();
}

async function saveRange() {
  const min = parseFloat(minInput.value);
  const max = parseFloat(maxInput.value);
  if (Number.isNaN(min) || Number.isNaN(max)) return;
  await fetch(`${API_BASE}/api/auto-range?token=${TOKEN}&min=${min}&max=${max}`);
  updateData();
}

onBtn.addEventListener("click", () => setRelay("on"));
offBtn.addEventListener("click", () => setRelay("off"));
manualBtn.addEventListener("click", () => setMode("manual"));
autoBtn.addEventListener("click", () => setMode("auto"));
saveRangeBtn.addEventListener("click", saveRange);

setInterval(updateData, 5000);
updateData();
