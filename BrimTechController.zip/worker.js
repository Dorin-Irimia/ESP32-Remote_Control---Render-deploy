export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;

    // Static assets (HTML/CSS/JS)
    if (!path.startsWith("/api/")) {
      // Serve files from /public via ASSETS binding
      return env.ASSETS.fetch(request);
    }

    // ==== TOKEN SECURITY ====
    const token = url.searchParams.get("token");
    if (token !== env.TOKEN) {
      return json({ error: "Unauthorized" }, 401);
    }

    // ==== API ROUTES ====
    if (path === "/api/update") return updateFromESP(url, env);
    if (path === "/api/temp") return readStatus(env);
    if (path === "/api/relay") return browserSetRelay(url, env);
    if (path === "/api/relay-state") return espGetRelay(env);
    if (path === "/api/mode") return browserSetMode(url, env);
    if (path === "/api/auto-range") return browserSetAutoRange(url, env);

    return new Response("Not found", { status: 404 });
  }
};

// ====== HELPERS & HANDLERS ======

async function updateFromESP(url, env) {
  const temp = url.searchParams.get("temp");
  const relay = url.searchParams.get("relay");

  if (temp !== null) await env.STATE.put("temp", temp);
  if (relay !== null) await env.STATE.put("relayESP", relay);
  await env.STATE.put("lastEspUpdate", Date.now().toString());

  return json({ status: "ok" });
}

async function readStatus(env) {
  const temp = await env.STATE.get("temp");
  const relaySet = await env.STATE.get("relaySet");
  const relayESP = await env.STATE.get("relayESP");
  const mode = await env.STATE.get("mode");
  const minTemp = await env.STATE.get("minTemp");
  const maxTemp = await env.STATE.get("maxTemp");
  const lastEspUpdate = await env.STATE.get("lastEspUpdate");
  const lastBrowserUpdate = await env.STATE.get("lastBrowserUpdate");

  return json({
    temp: temp ?? "0",
    relaySet: relaySet ?? "off",
    relayESP: relayESP ?? "off",
    mode: mode ?? "manual",
    minTemp: minTemp ?? "20",
    maxTemp: maxTemp ?? "23",
    lastEspUpdate,
    lastBrowserUpdate
  });
}

async function browserSetRelay(url, env) {
  const state = url.searchParams.get("state");
  if (state !== "on" && state !== "off") {
    return json({ error: "Invalid state" }, 400);
  }

  await env.STATE.put("relaySet", state);
  await env.STATE.put("lastBrowserUpdate", Date.now().toString());

  return json({ relaySet: state });
}

async function espGetRelay(env) {
  const relaySet = await env.STATE.get("relaySet");
  return new Response(relaySet ?? "off", {
    status: 200,
    headers: { "Content-Type": "text/plain" }
  });
}

async function browserSetMode(url, env) {
  const mode = url.searchParams.get("value");
  if (mode !== "manual" && mode !== "auto") {
    return json({ error: "Invalid mode" }, 400);
  }
  await env.STATE.put("mode", mode);
  await env.STATE.put("lastBrowserUpdate", Date.now().toString());
  return json({ mode });
}

async function browserSetAutoRange(url, env) {
  const minTemp = url.searchParams.get("min");
  const maxTemp = url.searchParams.get("max");

  if (minTemp === null || maxTemp === null) {
    return json({ error: "Missing min/max" }, 400);
  }

  await env.STATE.put("minTemp", minTemp);
  await env.STATE.put("maxTemp", maxTemp);
  await env.STATE.put("lastBrowserUpdate", Date.now().toString());

  return json({ minTemp, maxTemp });
}

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}
